create
    definer = root@localhost function HautdeGamme(id int) returns bit
BEGIN
    DECLARE HautdeGamme BIT(1);
    DECLARE price integer;
    DECLARE gala char(3);
    SELECT O.prix, G.gala
        INTO price, gala
    FROM oeuvres O LEFT OUTER JOIN galeries G ON G.id = O.galerie WHERE O.id = id;
    IF price > 250 THEN
        SET HautdeGamme = 1;
    ELSEIF price >=200 AND price <=250 AND gala = "oui" THEN
        SET HautdeGamme = 1;
    ELSE
        SET HautdeGamme = 0;
    end if;
    RETURN HautdeGamme;
end;

