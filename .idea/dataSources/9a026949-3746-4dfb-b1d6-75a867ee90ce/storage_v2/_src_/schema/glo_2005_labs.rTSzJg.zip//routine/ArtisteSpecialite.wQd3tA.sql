create
    definer = root@localhost function ArtisteSpecialite(surnom varchar(100)) returns varchar(100)
BEGIN
    DECLARE specialite varchar(100);
    SELECT A.specialite
        INTO specialite
        FROM artistes A WHERE A.surnom = surnom;
    RETURN specialite;
end;

