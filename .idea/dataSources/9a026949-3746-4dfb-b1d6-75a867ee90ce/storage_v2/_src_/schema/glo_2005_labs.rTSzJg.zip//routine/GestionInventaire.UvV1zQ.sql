create
    definer = root@localhost procedure GestionInventaire(IN NoBoutique int, IN NoItem int, IN couleur char(10), IN valeur int)
BEGIN
DECLARE Bcount integer;
DECLARE Ccount, Icount integer;
SET Bcount = (SELECT COUNT(*) FROM Boutiques B WHERE B.bid = NoBoutique);
SET Ccount = (SELECT COUNT(*) FROM Catalogue C WHERE C.cid = NoItem);
SELECT Icount = COUNT(*) FROM Inventaire I WHERE I.cid = NoItem AND I.bid = NoBoutique AND I.couleur = couleur;
IF (Bcount = 0) OR (Ccount = 0) THEN
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Boutique ou item inconnue';
END IF;
SELECT I.quantite INTO @oldval FROM Inventaire I WHERE I.cid = NoItem AND I.bid = NoBoutique AND I.couleur = couleur;
IF Icount = 0 AND valeur > 0 THEN
INSERT INTO Inventaire(CID, BID, Quantite, Couleur) VALUES (NoItem, NoBoutique, valeur, couleur);
ELSEIF @oldval + valeur > 0 THEN
UPDATE Inventaire SET quantite = quantite + valeur WHERE cid = NoItem AND bid = NoBoutique AND couleur = couleur;

ELSEIF (SELECT I.quantite FROM Inventaire I WHERE I.cid = NoItem AND I.bid = NoBoutique AND I.couleur = couleur)  + valeur = 0 THEN

DELETE FROM Inventaire WHERE cid = NoItem AND bid = NoBoutique AND couleur = couleur;
ELSE
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Rupture de stock';
END IF;
END;

