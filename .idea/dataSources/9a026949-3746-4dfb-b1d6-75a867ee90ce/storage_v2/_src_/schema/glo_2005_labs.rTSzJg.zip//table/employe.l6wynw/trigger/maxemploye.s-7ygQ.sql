create definer = root@localhost trigger MaxEmploye
    before insert
    on employe
    for each row
BEGIN
        IF (SELECT COUNT(*) FROM Employe WHERE galerie = NEW.galerie) = 2 THEN
            SIGNAL SQLSTATE "45000" SET MESSAGE_TEXT = "MAximum Employe atteint";
        end if ;
    end;

