create
    definer = root@localhost procedure ReadOeuvres()
BEGIN
    DECLARE id integer;
    DECLARE titre varchar(100);
    DECLARE prix integer;
    DECLARE hautDeGamme BIT(1);
    DECLARE lecture_complete bit(1) DEFAULT FALSE;
    DECLARE curseur CURSOR FOR SELECT O.id, O.titre, O.prix, HautDeGamme(O.id)
    FROM oeuvres O;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET lecture_complete = TRUE;

    CREATE TABLE IF NOT EXISTS SpecialPrices (id integer, titre varchar(100), prix integer, hautDeGamme bit(1));

    OPEN curseur;
    lecteur: LOOP
        FETCH curseur into id, titre, prix, hautDeGamme;
        IF lecture_complete = TRUE THEN
            LEAVE lecteur;
        end if;

        IF hautDeGamme = TRUE THEN
            INSERT INTO SpecialPrices VALUES (id, titre, prix * 1.5, TRUE);
        ELSE
            INSERT INTO SpecialPrices VALUES (id, titre, prix, FALSE);
        end if;
    end loop lecteur;
    CLOSE curseur;
end;

