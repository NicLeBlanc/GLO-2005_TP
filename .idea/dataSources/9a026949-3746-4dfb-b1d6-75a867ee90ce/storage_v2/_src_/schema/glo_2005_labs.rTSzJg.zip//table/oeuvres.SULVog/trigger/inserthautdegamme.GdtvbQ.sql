create definer = root@localhost trigger InsertHautDeGamme
    before update
    on oeuvres
    for each row
BEGIN
        DECLARE gala CHAR(3);
        SELECT G.gala INTO gala FROM galeries G WHERE id = NEW.galerie;
        IF NEW.prix > 250 THEN
            SET NEW.hautDeGamme = 1;
        ELSEIF NEW.prix >= 200 AND NEW.prix <= 250 AND gala = "oui" THEN
            SET NEW.hautDeGamme = 1;
        ELSE
            SET NEW.hautDeGamme = 0;
        end if;
    end;

